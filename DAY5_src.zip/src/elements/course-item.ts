import { bindable, inject } from 'aurelia-framework';
import { CourseModel } from 'models/coursemodel';
import { EventAggregator } from 'aurelia-event-aggregator';

@inject(EventAggregator)
export class CourseItem {
    @bindable coursedetails: CourseModel;
    addToCart: boolean = false;
    sortTerm: string;
    searchTerm: string = "React";

    constructor(public ea: EventAggregator) {

    }

    IncrementLikes(): void {
        this.coursedetails.likes++;
    }
    DeleteACourse(): void {
        //  publish
        let ans = confirm('Are you sure you want to delete ' + this.coursedetails.name + " ? ");
        if (ans) {
            this.ea.publish('delete', this.coursedetails.id);
        }
    }
}