import {inject,bindable} from 'aurelia-framework';
import * as $ from 'jquery';
import 'bootstrap';

@inject(Element)
export class TooltipCustomAttribute{
    element:Element;
    @bindable title:string;
    @bindable placement:string;

    constructor(element:Element){
        this.element = element
    }

    attached() {
        // gets called what attached to DOM
        console.log('Attached !');
        (<any>$(this.element)).tooltip({title:this.title,placement:this.placement});
    }
    detached() {
        (<any>$(this.element)).tooltip("dispose");

    }
}