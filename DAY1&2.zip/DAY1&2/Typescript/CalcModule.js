"use strict";
// import Add,{Product} from './MathModule';
exports.__esModule = true;
var MathModule = require("./MathModule");
console.log(MathModule.Addition(20, 30));
