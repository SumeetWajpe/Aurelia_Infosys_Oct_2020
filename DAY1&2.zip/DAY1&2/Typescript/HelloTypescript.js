var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//var x = 10; // Type Inference
var x; // Type Annotation
x = 100;
var str;
var b;
// var o;
// o = 1000;
// o = "Hello";
// o = {name:'Aurelia'};
// o = [10,20,30];
// var -> create global/function scoped
// let -> create block scoped variable
// -> stops variable hoisting
// -> stops duplicate identifiers
// if (true) {
//     let blockScoped:number;  // decl
//     blockScoped = 1000; // defn
//     if (true) {
//         console.log(blockScoped);
//     }
// }
// const -> block scoped , constants , decl + defn
var PI = 3.14;
// PI = 3.14543; // ERROR !
function Add(x, y) {
    if (x < 0) {
        return 'x should be greater than 0 ! ';
    }
    return x + y;
}
var result = Add(10, 20);
//console.log('The addition is : ' + result);
// Add("Hello","Typescript"); //Error 
// Arrays
//var cars:string[] = ["BMW","AUDI","FERRARI"];
// OR using Generics
//var moreCars:Array<string> = new Array<string>('TATA','MAHINDRA','MARUTI');
// Spread Operator [Arrays]
//var allCars:string[] = [...cars,...moreCars];
// = ["BMW","AUDI","FERRARI",'TATA','MAHINDRA','MARUTI']
//cars[0] = "TOYOTA";
// for(let c in allCars){
//     console.log(allCars[c]); //??
// }
// ES6 -> for - of
// for(let c of allCars){
//     console.log(c);
// }
// Spread Operator {Objects}
// var person = {name:'Virat',city:'Delhi'}; // Literal way
// var player = {...person,city:'Bengaluru',isCaptain:true};
// console.log(player.city);
// Destructuring (ES6) Arrays + Objects
// var cars:string[] = ["BMW","AUDI","FERRARI"];
// //var firstCar,secondCar;
// var [firstCar,,secondCar] = cars;
// console.log(secondCar);
// Destructuring with Objects
// var person = {fname:'Virat',city:'Delhi'};
// var fname:string,city:string;
// ({city,fname} = person);
//Enhanced Object Literal Syntax
var fname = "Virat", city = "Delhi";
//var person = {fname:fname,city:fname};
// OR
var person = { fname: fname, city: city };
// Optional parameters
// function PrintBooks(title?:string,author?:string){
//     console.log(title,author);
// }
// PrintBooks();
// PrintBooks("Wings of Fire","Dr. APJ Abdul Kalam");
// Default parameters
// function PrintBooks(title:string="Wings of Fire",author:string="Dr. APJ Abdul Kalam"){
//     console.log(title,author);
// }
// PrintBooks();
// // PrintBooks("India 2020");
// PrintBooks(undefined,"UnknownAuthor");
// Rest Parameters 
// function PrintBooks(author:string,...titles:string[]){   
//     console.log(author,titles);
// }
// PrintBooks("Dr. APJ Abdul Kalam","India 2020","Wings Of Fire");
// function declaration syntax
// function Square(x){
//     return x * x;
// }
// function as an expression
// var Square = function(x){
//     return x * x;
// }
// Arrow functions
// var Square = (x) =>{
//     return x  * x ;
// }
// OR
var Square = function (x) { return x * x; };
console.log(Square(10));
var cars = ["BMW", "AUDI", "FERRARI"];
var user = { name: 'Sumeet', password: '*****' };
// Classes
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "BMW"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        //console.log('The car ' + this.name + " is running at " + this.speed + " kmph !")
        return ("The car " + this.name + " is running at " + this.speed + " kmph ! ");
    };
    return Car;
}());
// var carObj = new Car();
// carObj.accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, nitroPower) {
        var _this = _super.call(this, name, speed) || this;
        _this.useNitroPower = nitroPower;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + " Can It Use Nitro power ?" + this.useNitroPower;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Audi", 300, true);
console.log(jbc.accelerate());
// var multiLineStr = `First Line
// Second Line
// Last  Line !`;
// console.log(multiLineStr);
