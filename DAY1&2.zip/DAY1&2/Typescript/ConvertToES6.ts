let es6var:string = "ES 6 variable using let !"
var Square = (x:any) => x * x;
console.log(Square(10));