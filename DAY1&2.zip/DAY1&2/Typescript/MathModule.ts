export function Addition(x:number,y:number){
    return x + y;
}

export function Product(x:number,y:number){
    return x * y;
}
