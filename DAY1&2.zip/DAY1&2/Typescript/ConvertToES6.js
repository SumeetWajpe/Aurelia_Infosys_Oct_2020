let es6var = "ES 6 variable using let !";
var Square = (x) => x * x;
console.log(Square(10));
