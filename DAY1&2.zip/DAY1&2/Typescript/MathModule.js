"use strict";
exports.__esModule = true;
exports.Product = exports.Addition = void 0;
function Addition(x, y) {
    return x + y;
}
exports.Addition = Addition;
function Product(x, y) {
    return x * y;
}
exports.Product = Product;
