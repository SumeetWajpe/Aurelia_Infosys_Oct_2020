//var x = 10; // Type Inference
var x: number; // Type Annotation
x = 100;
var str: string;
var b: boolean;

// var o;
// o = 1000;
// o = "Hello";
// o = {name:'Aurelia'};
// o = [10,20,30];
// var -> create global/function scoped
// let -> create block scoped variable
        // -> stops variable hoisting
        // -> stops duplicate identifiers
// if (true) {
//     let blockScoped:number;  // decl
//     blockScoped = 1000; // defn
//     if (true) {
//         console.log(blockScoped);
//     }
// }

// const -> block scoped , constants , decl + defn
const PI:number = 3.14;
// PI = 3.14543; // ERROR !

function Add(x:number,y:number):number|string{
    if(x<0){
        return 'x should be greater than 0 ! '
    }
    return x + y;
}

var result:number|string = Add(10,20);
//console.log('The addition is : ' + result);
// Add("Hello","Typescript"); //Error 

// Arrays
//var cars:string[] = ["BMW","AUDI","FERRARI"];

// OR using Generics
//var moreCars:Array<string> = new Array<string>('TATA','MAHINDRA','MARUTI');

// Spread Operator [Arrays]
//var allCars:string[] = [...cars,...moreCars];
                    // = ["BMW","AUDI","FERRARI",'TATA','MAHINDRA','MARUTI']

                    //cars[0] = "TOYOTA";
                    // for(let c in allCars){
//     console.log(allCars[c]); //??
// }
// ES6 -> for - of
// for(let c of allCars){
//     console.log(c);
// }

// Spread Operator {Objects}
// var person = {name:'Virat',city:'Delhi'}; // Literal way
// var player = {...person,city:'Bengaluru',isCaptain:true};
// console.log(player.city);

// Destructuring (ES6) Arrays + Objects
// var cars:string[] = ["BMW","AUDI","FERRARI"];
// //var firstCar,secondCar;
// var [firstCar,,secondCar] = cars;
// console.log(secondCar);

// Destructuring with Objects
// var person = {fname:'Virat',city:'Delhi'};
// var fname:string,city:string;
// ({city,fname} = person);

//Enhanced Object Literal Syntax
var fname:string="Virat",city:string="Delhi";
//var person = {fname:fname,city:fname};
// OR
var person = {fname,city};
// Optional parameters
// function PrintBooks(title?:string,author?:string){
//     console.log(title,author);
// }

// PrintBooks();
// PrintBooks("Wings of Fire","Dr. APJ Abdul Kalam");

// Default parameters
// function PrintBooks(title:string="Wings of Fire",author:string="Dr. APJ Abdul Kalam"){
   
//     console.log(title,author);
// }

// PrintBooks();
// // PrintBooks("India 2020");
// PrintBooks(undefined,"UnknownAuthor");

// Rest Parameters 
// function PrintBooks(author:string,...titles:string[]){   
//     console.log(author,titles);
// }

// PrintBooks("Dr. APJ Abdul Kalam","India 2020","Wings Of Fire");


// function declaration syntax
// function Square(x){
//     return x * x;
// }

// function as an expression
// var Square = function(x){
//     return x * x;
// }

// Arrow functions
// var Square = (x) =>{
//     return x  * x ;
// }

// OR
var Square = (x:number) => x * x;
console.log(Square(10));

var cars:string[] = ["BMW","AUDI","FERRARI"];
// cars.forEach(function(car,index){
//     console.log((index+1) + ". " + car);
// });

//cars.forEach((car,index)=>console.log((index+1) + ". " + car));

// function Emp(){
//     this.salary = 50000;            
//     setTimeout(()=>console.log(this.salary),2000);           
// }
// var e = new Emp();   


// Interface (TS)

interface IUser{
        name:string;
        password:string;
        profilePic?:string;
        getUserDetails?():void;
}

var user:IUser = {name:'Sumeet',password:'*****'};

class Person{
    name:string;
}

class User extends Person implements IUser{        
        password:string;
        profilePic:string;
        getUserDetails(){
            console.log(this.name  + " has " + this.password)
        }
}


// Classes

class Car{
    // private id:number;
    name:string;
    speed:number;
  
    constructor(name:string="BMW",speed:number=200){
        this.name = name;
        this.speed = speed;
    } 
    accelerate():string{
        //console.log('The car ' + this.name + " is running at " + this.speed + " kmph !")
        return (`The car ${this.name} is running at ${this.speed} kmph ! `)
    }
}

//var carObj = new Car();
// carObj.accelerate();

class JamesBondCar extends Car{
        useNitroPower:boolean;
        constructor(name?:string,speed?:number,nitroPower?:boolean){
            super(name,speed);
            this.useNitroPower = nitroPower;
        }

        accelerate():string{
            return super.accelerate() + " Can It Use Nitro power ?" + this.useNitroPower;
        }
}

var jbc = new JamesBondCar("Audi",300,true);
console.log(jbc.accelerate());


// var multiLineStr = `First Line
// Second Line
// Last  Line !`;
// console.log(multiLineStr);

// Enhanced Class Syntax

class EnhancedCar{
    constructor(public name:string="i20",public speed:number=100){

    }
}

var eCar = new EnhancedCar();

// Generics

function Swap<T>(x:T,y:T){
    let temp:T;
    temp = x;
    x = y;
    y = temp;
    console.log(x,y);
}

Swap<number>(10,20);

class Point<T,V>{
    x:T;
    y:V;
}
var pointObj = new Point<number,string>();