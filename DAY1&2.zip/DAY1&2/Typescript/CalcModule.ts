// import Add,{Product} from './MathModule';

import * as MathModule from './MathModule';

console.log(MathModule.Addition(20,30));