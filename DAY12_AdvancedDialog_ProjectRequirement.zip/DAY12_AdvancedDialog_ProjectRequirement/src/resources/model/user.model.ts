export class User{
    constructor(
        public name?:string,
        public email?:string,
        public certification?:string,
        public avatarUrl?:string,
        public skills?:string[],
        public rating?:number
    ){

    }
}