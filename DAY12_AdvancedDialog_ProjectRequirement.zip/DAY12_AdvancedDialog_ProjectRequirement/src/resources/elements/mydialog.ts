import { DialogController } from 'aurelia-dialog';
import {bindable,autoinject} from 'aurelia-framework';
@autoinject()
export class Mydialog {
        message:string="";
        header:string="";
        constructor(private controller:DialogController){

        }
        activate(msg) {
            this.message = msg.maincontent;
            this.header = msg.heading;
        }   
}
