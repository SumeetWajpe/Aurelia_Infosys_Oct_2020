import {bindable} from 'aurelia-framework';
import { connectTo, Store } from 'aurelia-store';
import { autoinject } from "aurelia-framework";
import { State } from 'resources/store/store';
import {  fetchpostsAction } from "../actions/actions";

@autoinject()
@connectTo()
export class PostsUi {
  public state:State;
  constructor(private store:Store<State>){
    this.store.registerAction('FetchPosts',fetchpostsAction);
  }
  attached() {
    this.store.dispatch(fetchpostsAction);
  }
}
