import {bindable,autoinject} from 'aurelia-framework';
import { User } from 'resources/model/user.model';
import { DialogService } from "aurelia-dialog";
import { Userdetails } from './userdetails';
import { Edituserdetails } from './edituserdetails';

@autoinject()
export class Userthumbnail {
  user:User;
  constructor(private dialogSrv:DialogService){
    this.user = new User(
      "Mr. Sumeet",
      "sumeet.wajpe@hotmail.com",
      "MCT",
      "./avatar.jpg",
      ['React','Angular','Vue','Aurelia'],
      5);
  }

  btnOpenUserDetails(mode){
    this.dialogSrv.open({viewModel:Userdetails,model:{user:this.user,mode},lock:true})
    .whenClosed(response=>{
        if(!response.wasCancelled){
            console.log('U clicked OK !')
        }else{
            console.log('U clicked cancel !')
        }
        if(response.output){
                   this.user = response.output;// changes from the user object !
                console.log(response.output)
                  }
    })
  }

  // btnEditUserDetails(){
  //   this.dialogSrv.open({viewModel:Edituserdetails,model:{user:this.user},lock:true})
  //   .whenClosed(response=>{
  //       if(!response.wasCancelled){
  //           console.log('U clicked OK !')
  //       }else{
  //           console.log('U clicked cancel !')
  //       }
  //       if(response.output){
  //         this.user = response.output;// changes from the user object !
  //       }
  //   })
  //}
}
