import {bindable} from 'aurelia-framework';

export class Viewedituser {
  @bindable value;

  valueChanged(newValue, oldValue) {
    //
  }
}
