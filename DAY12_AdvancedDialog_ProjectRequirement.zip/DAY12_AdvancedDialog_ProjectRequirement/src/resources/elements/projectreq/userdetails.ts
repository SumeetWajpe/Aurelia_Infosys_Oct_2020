import { DialogController } from 'aurelia-dialog';
import { bindable, autoinject } from 'aurelia-framework';
import { User } from 'resources/model/user.model';

@autoinject()
export class Userdetails {
    user: User; 
    mode:string;  
    @bindable rating:number;
    constructor(private controller: DialogController) {

    }
    activate(details) { // received from userthumbnail ! 
     this.user = {...details.user};
     this.mode = details.mode;
     this.rating = this.user.rating;
    }
    ratingChanged(newValue,oldValue){
      console.log('changed !',oldValue,newValue);
      this.user.rating = parseInt(newValue);
    }
}