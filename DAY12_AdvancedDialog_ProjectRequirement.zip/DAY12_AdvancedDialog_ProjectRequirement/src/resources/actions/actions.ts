import { HttpClient } from "aurelia-fetch-client";
import { State } from "resources/store/store";

// to update the store with new state ! - Synchronous Actions
// export const addAction = (state:State,theNewProduct:string)=>{
//     // Bad practise as state may contain other data !  
//     //console.log('Within Action :: Change Store here..');
//       //return {products:[...state.products,theNewProduct]};// new state (store)

//       // Update store based on to a condition
//       // Object.assign({},state);
//       // if(state.products.length <5){
//       //   var newState = Object.assign({},state);
//       //   newState.products = [...state.products,theNewProduct];    
//       //   return newState;
//       // }    
//       // return state;

//         var newState = Object.assign({},state);
//         newState.products = [...state.products,theNewProduct];    
//         return newState;
//   }


export const addAction = async (state: State, theNewProduct: string) => {
  // check for duplication using an API (promise)
  //  let thePromise = checkDuplicateAsync(theNewProduct,state);
  //  thePromise.then(
  //    response=>console.log(response),
  //    err=>console.log(err)
  //  );
  try {
    let theResponse = await checkDuplicateAsync(theNewProduct, state);
    var newState = Object.assign({}, state);
    newState.products = [...state.products, theNewProduct];  //  keep other state intact just change the products !
    return newState;
  }
  catch (ex) {
    var newState = Object.assign({}, state);
    newState.error = ex.message; // keep other state intact just change the error !
    return newState;
  }
}

function checkDuplicateAsync(pName: string, state: State) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      // based on the condition resolve or reject !
      if (state.products.includes(pName)) {
        reject(new Error(`Can't add duplicate Item !`))
      } else {
        resolve(pName);
      }
    }, 2000)
  });
}

export const fetchpostsAction = async (state: State) => {
  try {
    var response: any = await fetchAllPosts();
    var newState = Object.assign({}, state);
    newState.posts = [...response];
    return newState;
  } catch (ex) {
    var newState = Object.assign({}, state);
    newState.error = ex.message; // keep other state intact just change the error !
    return newState;
  }
}

function fetchAllPosts() {
  // aurelia-fetch-client
  return new Promise((resolve, reject) => {
    let httpClient = new HttpClient();
    httpClient.get('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(allPosts => resolve(allPosts))
      .catch(err => reject(new Error(err)))
  })
}