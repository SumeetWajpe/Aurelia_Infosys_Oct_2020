import { HttpClient } from "aurelia-fetch-client";

export class PostsService{
    httpClientObj:HttpClient = new HttpClient();

    getAllPosts():Promise<Response>{
        return this.httpClientObj.fetch('https://jsonplaceholder.typicode.com/posts')
    }

}