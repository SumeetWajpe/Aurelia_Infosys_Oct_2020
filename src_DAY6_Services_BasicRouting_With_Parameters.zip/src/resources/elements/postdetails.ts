import {bindable,inject} from 'aurelia-framework';
import { Router } from "aurelia-router";

@inject(Router)
export class Postdetails {
  thePostId:number;
  constructor(public router:Router){}

  activate(params){
    this.thePostId = params.id;
  }
}
