import { RouterConfiguration,Router } from "aurelia-router";
import {PLATFORM} from 'aurelia-pal';

export class App {
  header:string = 'Courses';  
  router:Router;
  configureRouter(config:RouterConfiguration,router:Router):void{
    this.router = router;
    config.options.pushState = true;
    config.map([
      {route:['','home'], name:'home',moduleId:PLATFORM.moduleName('./resources/elements/course-list')},
      {route:'posts', name:'posts',moduleId:PLATFORM.moduleName('./resources/elements/posts')},
      {route:'postdetails/:id', name:'postdetails',moduleId:PLATFORM.moduleName('./resources/elements/postdetails')}

    ]);
    config.mapUnknownRoutes(PLATFORM.moduleName('./resources/elements/resourcenotfound'))
  }
}
