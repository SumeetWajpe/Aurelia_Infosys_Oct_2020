export class App {
  header:string = 'Courses';  
}
