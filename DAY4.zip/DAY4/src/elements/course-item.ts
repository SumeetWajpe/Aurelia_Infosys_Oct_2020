import {bindable} from 'aurelia-framework';
import { CourseModel } from 'models/coursemodel';

export class CourseItem{
    @bindable coursedetails:CourseModel;
    addToCart:boolean=false;

    IncrementLikes():void{
        this.coursedetails.likes++;
    }
}