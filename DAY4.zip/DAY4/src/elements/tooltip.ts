import {inject} from 'aurelia-framework';
import * as $ from 'jquery';
import 'bootstrap';

@inject(Element)
export class TooltipCustomAttribute{
    element:Element;

    constructor(element:Element){
        this.element = element
    }

    attached() {
        // gets called what attached to DOM
        console.log('Attached !');
        (<any>$(this.element)).tooltip({title:'This is tooltip !'});
    }
    detached() {
        console.log('Detached')
    }
}