export class CourseModel{    
    constructor(
        public id:number,
        public name:string,
        public price:number,
        public rating:number,
        public likes:number,
        public status:string,
        public imageUrl:string="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/No_image_available.svg/600px-No_image_available.svg.png"
        ){

    }
}