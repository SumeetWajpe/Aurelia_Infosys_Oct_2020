export class SortCoursesValueConverter{
    toView(arr:any[],property:string="name",direction:string="ascending"){
        
        var sorted = arr.sort((obj1:any,obj2:any)=> obj1[property] - obj2[property] )
        return sorted;
       // return direction === 'ascending' ? sorted : sorted.reverse();
    }
}

// var course = {name:'Angular',rating:5}
//course.name -> console.log()
// course["name"] -> associative array 