import numeral from 'numeral';

export class CurrencyFormatValueConverter{
    toView(value,format='0,0'){
        return numeral(value).format(format);
    }
}