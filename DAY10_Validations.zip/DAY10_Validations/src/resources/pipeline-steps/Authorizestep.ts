import { AuthService } from "../services/auth.service";
import {inject} from 'aurelia-framework';
import { Redirect } from "aurelia-router";

@inject(AuthService)
export class AuthorizeStep{
    // biz logic to check authentication
    
    constructor(public authSrvObj:AuthService){}
    run(navigationInstruction,next){    
        console.log('Within run -> AuthorizeStep ! ')   
        if(navigationInstruction.getAllInstructions().some(i => i.config.settings.auth)){
            if(!this.authSrvObj.currentUser){
                console.log('Within run -> AuthorizeStep (User not uthenticated !) !');
                return next.cancel(new Redirect("login")); // cancel & redirect to login
            } 
        }
        return next();  // must return next() -> next step
    }
}


@inject(AuthService)
export class AuthorizeStep2{
    // biz logic to check authentication    
    constructor(public authSrvObj:AuthService){}
    run(navigationInstruction,next){    
        console.log('Within run -> AuthorizeStep2 ! ')   
        if(navigationInstruction.getAllInstructions().some(i => i.config.settings.auth)){
            if(!this.authSrvObj.currentUser){
                console.log('Within run -> AuthorizeStep (User not uthenticated !) !');
                return next.cancel(new Redirect("login")); // cancel & redirect to login
            }           
        }
        return next();  // must return next() -> next step
    }
}