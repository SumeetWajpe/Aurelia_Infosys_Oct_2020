import { HttpClient } from "aurelia-fetch-client";

export class UsersService{
    httpClientObj:HttpClient = new HttpClient();

    getAllUsers():Promise<Response>{
        return this.httpClientObj.fetch('https://jsonplaceholder.typicode.com/users')
    }

    getUserById(theUserId):Promise<Response>{
        return this.httpClientObj.fetch('https://jsonplaceholder.typicode.com/users/' + theUserId)
    }

}