import {bindable,inject,NewInstance} from 'aurelia-framework';
import {validateTrigger, ValidationController,ValidationRules} from 'aurelia-validation';

@inject(NewInstance.of(ValidationController))
export class Projectspecificval {
      @bindable selectedType:string="";
      txtPhone:string="";
      constructor(public controller:ValidationController){
           this.controller.validateTrigger = validateTrigger.manual;
      }

      attached() {
            ValidationRules.ensure('txtPhone')
            .displayName('Phone Number')
            .minLength((this.selectedType === 'Internal') ? 3 : 7).withMessage(`\${$displayName} should be minimum ${(this.selectedType === 'Internal') ? 3 : 7} characters`)
            .on(this); 
      }

      selectedTypeChanged(){
            ValidationRules.ensure('txtPhone')
            .displayName('Phone Number')
            .minLength((this.selectedType === 'Internal') ? 3 : 7).withMessage(`\${$displayName} should be minimum ${(this.selectedType === 'Internal') ? 3 : 7} characters`)
            .on(this); 
           
      }
      ValidateOnClick(){
            this.controller.validate();
      }

}
