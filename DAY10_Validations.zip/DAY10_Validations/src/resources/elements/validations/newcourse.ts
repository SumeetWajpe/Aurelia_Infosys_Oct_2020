import {bindable,inject,NewInstance} from 'aurelia-framework';
import {ValidationController,ValidationRules,validationMessages} from 'aurelia-validation';

@inject(NewInstance.of(ValidationController))
export class Newcourse {
  @bindable coursename:string="";
  courseprice:number;
  courserating:number;
  isFormValid:boolean=false;
  shouldRangeValidate:boolean=false;

  constructor(public controller:ValidationController){
    //.ensure((nc:Newcourse)=>nc.coursename)   
    validationMessages['required'] = `\${$displayName} is missing !`;

    ValidationRules.customRule('ratingRange',(value,obj,min,max)=>{
        let aNumber = Number.parseInt(value);
        return aNumber === null || aNumber === undefined || (Number.isInteger(aNumber) && aNumber >= min && aNumber <= max)
    },
    '${$displayName} must be an integer between ${$config.min} and ${$config.max}',
    (min,max)=>({min,max})
    )

    ValidationRules
      .ensure('coursename')     
      .displayName('Course Name')
      .required()      
      .minLength(3).withMessage(`\${$displayName} must be atleast 3 characters !`)
      .ensure('courseprice')
      .displayName('Course Price')
      .required().withMessage(`\${$displayName} is required !!!`)
      .range(100,10000).withMessage(`\${$displayName} must be between 100 and 10000 !`)
      .ensure('courserating')
      .displayName('Rating')
      .required()
      .then()
      .satisfiesRule('ratingRange',1,5).when((nc:Newcourse)=> nc.shouldRangeValidate === true)
      .on(this);
  }

  coursenameChanged(newValue,oldValue){
    console.log(oldValue,newValue);
    // this.controller.validate(); // this triggers validation for all validation rules !
    //this.controller.validate({object:this,propertyName:'coursename'});
    //.then(r=>this.isFormValid = r.valid,e=>console.log(e));

    //console.log(this.controller);
  }

  get isTheFormValid(){
    if(this.controller.errors.length === 0)
        return true;
      else
        return false;
  }

  btnValidate(){
    this.controller.validate();
  }
  btnReset(){
    this.controller.reset();
  }
}
