import {bindable,inject} from 'aurelia-framework';
import { Router } from "aurelia-router";
import { PostsModel } from 'resources/models/postsmodel';
import { PostsService } from 'resources/services/posts.service';

@inject(Router,PostsService)
export class Postdetails {
  thePostId:number;
  thePost:PostsModel;
  constructor(public router:Router,public postSrvObj:PostsService){}

  activate(params){
    this.thePostId = params.id;
    this.postSrvObj.getPostById(this.thePostId)
    .then(response=>response.json())
    .then(thePost=>this.thePost = thePost);
  }

  NavigateBack(){
    this.router.navigateBack();//just the previous page (component)
  }
  NavigateToHome(){
    this.router.navigateToRoute('home');    
  }
}
