import {bindable} from 'aurelia-framework';
import {RouterConfiguration,Router} from 'aurelia-router';
import {PLATFORM} from 'aurelia-pal';

export class Users {
  router:Router;
   
    configureRouter(config: RouterConfiguration, router: Router): void {
      this.router = router;
      config.title = 'User List';
      config.map([
        { route: '', name: 'noselection', viewPorts:{list:{moduleId:PLATFORM.moduleName('./user-list')},details:{moduleId:PLATFORM.moduleName('./no-selection')} } },
        {route:'/:id',name:'userdetails',viewPorts:{ details:{moduleId:PLATFORM.moduleName('./user-details')}} ,  title:'User Details' }
      
      ]);
    }
}
