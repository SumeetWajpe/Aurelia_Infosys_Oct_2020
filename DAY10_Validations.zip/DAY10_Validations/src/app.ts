import { RouterConfiguration,Router } from "aurelia-router";
import {PLATFORM} from 'aurelia-pal';
import {autoinject} from 'aurelia-framework';
import { AuthService } from "resources/services/auth.service";
import {EventAggregator} from 'aurelia-event-aggregator';
import { AuthorizeStep,AuthorizeStep2 } from "./resources/pipeline-steps/Authorizestep";

@autoinject()
export class App {
  header:string = 'Courses';  
  router:Router;
  currentUser;
  subscription;
  constructor(public authSrvObj:AuthService,public ea:EventAggregator){
    this.currentUser =  this.authSrvObj.currentUser;
  }
  configureRouter(config:RouterConfiguration,router:Router):void{
    this.router = router; 
    config.options.pushState = true;
    //config.addAuthorizeStep(AuthorizeStep);
    //config.addAuthorizeStep(AuthorizeStep2);
    config.map([
      {route:['','login'], name:'login',moduleId:PLATFORM.moduleName('./resources/elements/login'),title:'Login'},
      {route:'courses', name:'courses',moduleId:PLATFORM.moduleName('./resources/elements/course-list'),nav:true,title:'Courses',settings:{auth:true}},
      {route:'posts', name:'posts',moduleId:PLATFORM.moduleName('./resources/elements/posts'),nav:true,title:'Posts',settings:{auth:true}},
      {route:'postdetails/:id', name:'postdetails',moduleId:PLATFORM.moduleName('./resources/elements/postdetails'),settings:{auth:true}},
      {route:'users', name:'users',moduleId:PLATFORM.moduleName('./resources/elements/users'),nav:true,title:'Users',settings:{auth:true}},,
      {route:'article', name:'article',moduleId:PLATFORM.moduleName('./resources/elements/article'),nav:true,title:'Articles',settings:{auth:true}},
      {route:'lifecycle', name:'lifecycle',moduleId:PLATFORM.moduleName('./resources/elements/lifecycle'),nav:true,title:'Lifecycle methods',settings:{auth:true}},

    ]);
    config.mapUnknownRoutes(PLATFORM.moduleName('./resources/elements/resourcenotfound'))
  }

  logout(){
    // One-way
    let theAns = confirm('Are u sure ?');
    if(theAns){
      this.authSrvObj.logout()
      .then(response=>{
        if(response){
          this.ea.publish('authenticated',null);
          this.router.navigateToRoute('login');
        }
      });
    }

    //another-way using pipeline-methods
    // this.authSrvObj.logout()
    // .then(response=>{
    //   if(response){
    //     this.ea.publish('authenticated',null);
    //     this.router.navigateToRoute('login');
    //   }
    // });

    
  }

  attached() {
    this.subscription = this.ea.subscribe('authenticated',user=> this.currentUser = user)
  }

  detached() {
    this.subscription.dispose();
  }
}
