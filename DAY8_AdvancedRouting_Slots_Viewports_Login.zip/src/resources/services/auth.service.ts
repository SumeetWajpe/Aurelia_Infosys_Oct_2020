export class AuthService{
    currentUser = null;
    listofusers = ['admin','sumeet'];

    login(name){
        return new Promise((resolve,reject)=>
            setTimeout(()=>{
                if(this.listofusers.includes(name)){
                    this.currentUser = name;
                    resolve({user:name})
                }else {
                    reject(new Error('Invalid Credentials !'))
                }
            },500)
        )
    }

    logout(){
        return new Promise((resolve,reject)=>{
            setTimeout(()=>{
                this.currentUser = null;
                if(this.currentUser){
                    reject(new Error('Error Logging out !'));
                }else{
                    resolve({success:true});
                }
            },500)
        })
    }

}