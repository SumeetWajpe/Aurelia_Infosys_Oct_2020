import {bindable} from 'aurelia-framework';

export class Article {
  @bindable value;

  valueChanged(newValue, oldValue) {
    //
  }
}
