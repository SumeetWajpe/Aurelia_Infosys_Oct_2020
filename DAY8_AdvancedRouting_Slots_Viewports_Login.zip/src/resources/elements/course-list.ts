import {bindable,inject} from 'aurelia-framework';
import { EventAggregator} from 'aurelia-event-aggregator';
import {CourseModel} from '../models/coursemodel';

@inject(EventAggregator)
export class CourseList{
   //headerImage:string="https://qph.fs.quoracdn.net/main-qimg-99a747af9c052844b1a7831615f798f4";
   theSubscription;
   courses:CourseModel[] = [
      {id:1,name:'Angular',price:5000,rating:4,likes:100,status:'Coming Soon',imageUrl:'https://www.ryadel.com/wp-content/uploads/2017/10/angular-logo.jpg'},
      {id:2,name:'React',price:6000,rating:3,likes:600,status:'Published',imageUrl:'https://miro.medium.com/max/3840/1*yjH3SiDaVWtpBX0g_2q68g.png'},
      {id:3,name:'Redux',price:7000,rating:5,likes:700,status:'Published',imageUrl:'https://redux.js.org/img/redux-logo-landscape.png'},
      {id:4,name:'Typescript',price:3000,rating:4.5,status:'Coming Soon',likes:400,imageUrl:'https://storage.googleapis.com/blog-images-backup/1*D8Wwwce8wS3auLAiM3BQKA.jpeg'},
      {id:5,name:'Vue',price:6000,rating:5,likes:600,status:'Published',imageUrl:'https://peerbits-wpengine.netdna-ssl.com/wp-content/uploads/2018/05/Vue.js-cta-main.jpg'}
    ];

    constructor(public ea:EventAggregator){
      this.theSubscription = this.ea.subscribe('delete',(theId)=>{
         let index = this.courses.findIndex(c=>c.id === theId);
         this.courses.splice(index,1);
      });
    }

    detached() {
       console.log('Detached !')
       this.theSubscription.dispose();// clean up !
    }
}