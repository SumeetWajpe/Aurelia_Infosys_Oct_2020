import {bindable,autoinject} from 'aurelia-framework';
import {AuthService} from '../services/auth.service';
import {Router} from 'aurelia-router';
@autoinject
export class Login {
  username:string;
  password:string;
  constructor(public authServObj:AuthService,public router:Router){

  }
  login(){
    this.authServObj.login(this.username)
    .then(theUser=> this.router.navigateToRoute('courses'))
    .catch(theError=>console.log(theError.message))
  }
}
