import {bindable,View} from 'aurelia-framework';

export class Lifecycle {
  constructor(){
    console.log('Within Constructor');
  }

  created(owningView: View, myView: View) {
    console.log('Within Created !');
  }

  bind(bindingContext: Object,overrideContext: Object) {
    console.log('Within bind !');    
  }

  attached() {
    console.log('Within Attached !');
  }

  unbind() {
    console.log('Within unbind !');    
  }

  detached() {
    console.log('Within detached !');    
  }
}
