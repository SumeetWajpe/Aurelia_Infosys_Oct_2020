import { RouterConfiguration,Router } from "aurelia-router";
import {PLATFORM} from 'aurelia-pal';
import {inject} from 'aurelia-framework';
import { AuthService } from "resources/services/auth.service";

@inject(AuthService)
export class App {
  header:string = 'Courses';  
  router:Router;
  currentUser;
  constructor(public authSrvObj:AuthService){
    this.currentUser =  this.authSrvObj.currentUser;
  }
  configureRouter(config:RouterConfiguration,router:Router):void{
    this.router = router;
    config.options.pushState = true;
    config.map([
      {route:['','login'], name:'login',moduleId:PLATFORM.moduleName('./resources/elements/login'),nav:true,title:'Login'},
      {route:'courses', name:'courses',moduleId:PLATFORM.moduleName('./resources/elements/course-list'),nav:true,title:'Courses'},
      {route:'posts', name:'posts',moduleId:PLATFORM.moduleName('./resources/elements/posts'),nav:true,title:'Posts'},
      {route:'postdetails/:id', name:'postdetails',moduleId:PLATFORM.moduleName('./resources/elements/postdetails')},
      {route:'users', name:'users',moduleId:PLATFORM.moduleName('./resources/elements/users'),nav:true,title:'Users'},,
      {route:'article', name:'article',moduleId:PLATFORM.moduleName('./resources/elements/article'),nav:true,title:'Articles'},
      {route:'lifecycle', name:'lifecycle',moduleId:PLATFORM.moduleName('./resources/elements/lifecycle'),nav:true,title:'Lifecycle methods'},

    ]);
    config.mapUnknownRoutes(PLATFORM.moduleName('./resources/elements/resourcenotfound'))
  }
}
