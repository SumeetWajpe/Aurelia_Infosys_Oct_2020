export class App {
  public message = 'Hello World!';
}
