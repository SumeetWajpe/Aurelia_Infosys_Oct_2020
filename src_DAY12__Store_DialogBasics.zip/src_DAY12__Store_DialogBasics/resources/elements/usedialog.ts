import {bindable,autoinject} from 'aurelia-framework';
import { DialogService } from "aurelia-dialog";
import { Mydialog } from "./mydialog";

@autoinject()
export class Usedialog {
  constructor(private dialogSrv:DialogService){

  }

  btnShowDialog(){
    this.dialogSrv.open({viewModel:Mydialog,model:{heading:'Parent Heading',maincontent:'Content from Parent !'},lock:false}).whenClosed(response=>{
        if(!response.wasCancelled){
            console.log('U clicked OK !')
        }else{
            console.log('U clicked cancel !')
        }
        console.log(response.output);
    })
  }
}
