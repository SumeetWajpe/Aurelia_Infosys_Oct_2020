import { Post } from "resources/model/post.model";

export interface State{
    products:string[];   
    posts:Post[]
    error:string;
}

export const initialState:State = {
    products:['Mobile Phones','Shoes','Camera'],
    posts:[],
    error:null
}