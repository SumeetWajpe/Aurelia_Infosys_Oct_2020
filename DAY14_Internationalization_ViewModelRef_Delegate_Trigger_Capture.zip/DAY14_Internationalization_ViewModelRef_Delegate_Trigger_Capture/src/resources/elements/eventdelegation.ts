import {bindable} from 'aurelia-framework';

export class Eventdelegation {
  DivParentHandler2(){
    console.log('Within DivParentHandler2 !')

  }
  DivParentHandler(){
    console.log('Within DivParentHandler !')
  }

  HandleButtonClick(e){

    console.log('Within HandleButtonClick 1 !');
    e.stopPropagation();
  }

  HandlerButtonClick2(e){
    console.log('Within HandleButtonClick 2 !');
    e.stopPropagation();
  }
}
