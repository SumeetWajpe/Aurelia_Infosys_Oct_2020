/* Another component exists viewedituser, use that ! */
import { DialogController } from 'aurelia-dialog';
import { bindable, autoinject } from 'aurelia-framework';
import { User } from 'resources/model/user.model';

@autoinject()
export class Edituserdetails {
  user: User;   
  @bindable rating:number;
    constructor(private controller: DialogController) {

    }
    activate(details) { // received from userthumbnail ! 
     //this.user = details.user; // point user to userdetails (reference)
      this.user = {...details.user}; // spread operator !
      this.rating = this.user.rating;
    }
    ratingChanged(oldValue,newValue){
      this.user.rating = this.rating;
    }
}
