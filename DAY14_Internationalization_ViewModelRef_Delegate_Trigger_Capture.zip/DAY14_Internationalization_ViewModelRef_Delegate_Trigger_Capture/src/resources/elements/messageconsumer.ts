import {bindable} from 'aurelia-framework';

export class Messageconsumer {
  @bindable outputmsg;
 
}
