import {bindable} from 'aurelia-framework';

export class Messageprovider {
  @bindable inputmsg;
 
}
