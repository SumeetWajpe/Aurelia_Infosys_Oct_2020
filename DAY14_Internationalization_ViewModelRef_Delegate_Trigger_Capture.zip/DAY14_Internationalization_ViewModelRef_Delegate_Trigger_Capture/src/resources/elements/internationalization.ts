import {bindable,autoinject} from 'aurelia-framework';
import {I18N} from 'aurelia-i18n';

@autoinject()
export class Internationalization {
  constructor(private i18N:I18N){
      
  }

  ChangeLocale(locale){
    this.i18N.setLocale(locale);
  }
}
