import {bindable,autoinject} from 'aurelia-framework';
import { connectTo, Store } from 'aurelia-store';
import { State } from 'resources/store/store';
import { Subscription } from 'rxjs';
import {pluck} from 'rxjs/operators';

@autoinject()
@connectTo()
export class Shoppingcart {
  public state:State;
  constructor(private store:Store<State>){
    //this.store.registerAction('AddAction',addAction);
  }  
}




//1. Explicit Binding With Bind() & Unbind()
// @autoinject()
// export class Shoppingcart {
//   public state:State;
//   private subscription:Subscription
//   constructor(private store:Store<State>){}

//   bind() {
//     this.subscription =  this.store.state.subscribe(s=>this.state = s);
//   }
//   unbind() {
//     this.subscription.unsubscribe();
//   }
// }


// 2. Using @connectTo()
// @autoinject()
// @connectTo()
// export class Shoppingcart {
//   public state:State;
//   constructor(private store:Store<State>){}
 
// }

// 3. using pluck in @connectTo()
// @autoinject()
// @connectTo<State>(store=>store.state.pipe(pluck('products')))
// export class Shoppingcart {
//   public state:State;
//   constructor(private store:Store<State>){}
 
// }