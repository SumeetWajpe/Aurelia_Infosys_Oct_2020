import {bindable,autoinject} from 'aurelia-framework';
import { connectTo, Store } from 'aurelia-store';
import { addAction } from 'resources/actions/actions';
import { State } from 'resources/store/store';

@autoinject()
@connectTo()
export class Newproduct {
  public state:State;
  public newproduct:string="";

  constructor(private store:Store<State>){
    this.store.registerAction('AddAction',addAction);
  }
  AddProduct(){
    this.store.dispatch(addAction,this.newproduct);
  }
}
