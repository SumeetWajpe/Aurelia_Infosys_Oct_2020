
export interface State{
    products:string[];
    posts:Post[];
}

export const initialState:State = {
    products:['Mobile Phones','Shoes','Camera'],
    posts:[]
}