import { State } from "resources/store/store";

// to update the store with new state !
export const addAction = (state:State,theNewProduct:string)=>{
    // Bad practise as state may contain other data !  
    //console.log('Within Action :: Change Store here..');
      //return {products:[...state.products,theNewProduct]};// new state (store)
  
      // Update store based on to a condition
      // Object.assign({},state);
      // if(state.products.length <5){
      //   var newState = Object.assign({},state);
      //   newState.products = [...state.products,theNewProduct];    
      //   return newState;
      // }    
      // return state;
  
        var newState = Object.assign({},state);
        newState.products = [...state.products,theNewProduct];    
        return newState;
  }