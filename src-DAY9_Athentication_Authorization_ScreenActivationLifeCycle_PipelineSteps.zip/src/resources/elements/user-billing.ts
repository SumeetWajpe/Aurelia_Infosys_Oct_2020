import {computedFrom,observable} from 'aurelia-framework';

export class UserBilling{
  name:string;
  houseNo:number;
  streetName:string;
  @observable city:string;

  @computedFrom('houseNo','streetName','city')
  get address(){
      return `${this.houseNo} , ${this.streetName} , ${this.city}`
  }

  cityChanged(newerValue,olderValue){
    console.log('Newer : ' + newerValue + " , Older : " + olderValue);
  }

}