import {bindable,inject,autoinject} from 'aurelia-framework';
import { PostsService } from "../services/posts.service";
import { EventAggregator } from "aurelia-event-aggregator";
import { PostsModel } from 'resources/models/postsmodel';

// @autoinject
@inject(PostsService)
export class Posts {
  allPosts:PostsModel[]=[];
  constructor(public postServObj:PostsService){

  }
  attached() {    
   this.postServObj.getAllPosts()
   .then(response=>response.json())
   .then(posts=>this.allPosts = posts)
  }
}
