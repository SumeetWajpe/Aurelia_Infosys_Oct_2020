import {bindable,autoinject} from 'aurelia-framework';
import {AuthService} from '../services/auth.service';
import {Router} from 'aurelia-router';
import {EventAggregator} from 'aurelia-event-aggregator';

@autoinject
export class Login {
  username:string;
  password:string;
  error:string;
  constructor(public authServObj:AuthService,public router:Router,public ea:EventAggregator){

  }

  activate() {
    this.error = null;
  }

  login(){
    this.error = null;
    this.authServObj.login(this.username)
    .then((theUser:any)=> {
      this.ea.publish('authenticated',theUser.user);
      this.router.navigateToRoute('courses');
    })
    .catch(theError=> this.error = theError.message)
  }
}
