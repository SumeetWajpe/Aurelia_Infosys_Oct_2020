import {bindable,autoinject} from 'aurelia-framework';
import { UsersService } from 'resources/services/users.service';

@autoinject
export class UserList {
  allUsers;
    constructor(public userSrvObj:UsersService){}

    attached() {
      this.userSrvObj.getAllUsers()
      .then(response=>response.json())
      .then(users=>this.allUsers = users)
    }
}
