import {bindable} from 'aurelia-framework';

export class Blog {
  @bindable value;

  valueChanged(newValue, oldValue) {
    //
  }
}
