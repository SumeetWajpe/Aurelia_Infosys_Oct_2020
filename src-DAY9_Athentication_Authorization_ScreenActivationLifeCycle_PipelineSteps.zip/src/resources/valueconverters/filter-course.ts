export class FilterCoursesValueConverter{
    toView(array:any[],searchTerm:string=""){
        return array.filter(item=>{
            return searchTerm && searchTerm.length > 0 ? this.itemMatcher(searchTerm,item) : true
        });
    }

    itemMatcher(searchTerm,value){
        let itemValue = value.name;
        if(!itemValue) return false;
        return itemValue.toUpperCase().indexOf(searchTerm.toUpperCase()) !== -1
    }   
    
}