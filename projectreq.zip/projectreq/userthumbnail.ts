import {bindable} from 'aurelia-framework';
import { User } from 'resources/model/user.model';

export class Userthumbnail {
  user:User;
  constructor(){
    this.user = new User(
      "Mr. Sumeet",
      "sumeet.wajpe@hotmail.com",
      "MCT",
      "./avatar.jpg",
      ['React','Angular','Vue','Aurelia'],
      5);
  }
}
