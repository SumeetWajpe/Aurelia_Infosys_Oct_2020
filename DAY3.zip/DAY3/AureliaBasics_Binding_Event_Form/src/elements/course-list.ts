import {bindable} from 'aurelia-framework'
export class CourseList{
   @bindable courses;
}