export class App {
  message:string = 'Courses';
  // courses:string[] = ['Angular','React','Typescript'];
  courses = [
    {name:'Angular',price:5000,rating:4},
    {name:'React',price:6000,rating:3},
    {name:'Redux',price:7000,rating:5},
    {name:'Typescript',price:3000,rating:4.5}
  ]
  newCourse:string="";

  addNewCourse():void{
    // add a new item to list of courses
    //this.courses.push({name:this.newCourse,});
    this.newCourse = "";
  }
}
