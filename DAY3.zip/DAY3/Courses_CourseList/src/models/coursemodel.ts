export class CourseModel{    
    constructor(
        public id:number,
        public name:string,
        public price:number,
        public rating:number,
        public likes:number
        ){

    }
}