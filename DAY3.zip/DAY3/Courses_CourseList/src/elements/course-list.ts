import {bindable} from 'aurelia-framework';
import {CourseModel} from '../models/coursemodel';

export class CourseList{
   courses:CourseModel[] = [
      {id:1,name:'Angular',price:5000,rating:4,likes:100},
      {id:2,name:'React',price:6000,rating:3,likes:600},
      {id:3,name:'Redux',price:7000,rating:5,likes:700},
      {id:4,name:'Typescript',price:3000,rating:4.5,likes:400},
      {id:5,name:'Vue',price:6000,rating:5,likes:600}
    ]
}