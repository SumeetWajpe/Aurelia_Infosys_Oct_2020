import {bindable,autoinject} from 'aurelia-framework';
import { UsersService } from 'resources/services/users.service';

@autoinject
export class UserDetails {
  theUser;
  constructor(public userSrvObj:UsersService){}

  activate(params) {
    this.userSrvObj.getUserById(params.id)
    .then(response=>response.json())
    .then(user=>this.theUser = user);
  }
}
