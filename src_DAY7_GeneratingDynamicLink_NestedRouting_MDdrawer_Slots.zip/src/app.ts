import { RouterConfiguration,Router } from "aurelia-router";
import {PLATFORM} from 'aurelia-pal';
import { title } from "process";

export class App {
  header:string = 'Courses';  
  router:Router;
  configureRouter(config:RouterConfiguration,router:Router):void{
    this.router = router;
    config.options.pushState = true;
    config.map([
      {route:['','home'], name:'home',moduleId:PLATFORM.moduleName('./resources/elements/course-list'),nav:true,title:'Courses'},
      {route:'posts', name:'posts',moduleId:PLATFORM.moduleName('./resources/elements/posts'),nav:true,title:'Posts'},
      {route:'postdetails/:id', name:'postdetails',moduleId:PLATFORM.moduleName('./resources/elements/postdetails')},
      {route:'users', name:'users',moduleId:PLATFORM.moduleName('./resources/elements/users'),nav:true,title:'Users'},

    ]);
    config.mapUnknownRoutes(PLATFORM.moduleName('./resources/elements/resourcenotfound'))
  }
}
